# Atividade Prática 02 - Biblioteca Persistente

Complete os arquivos da base usando SQLAlchemy ORM.

## Como executar

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
```

## Defesa escrita

Responda ao final:

1. Para que serve o campo `disponivel` em `Livro`?

## para ter a confirmação que o livro está disponivel e assim conseguir trabalhar.

2. Por que é necessário chamar `session.commit()` após emprestar ou devolver?

## para confirmar ou seja para salvar.

3. Em qual consulta você usa o relacionamento entre `Livro` e `Autor`?

## em listar livros.
